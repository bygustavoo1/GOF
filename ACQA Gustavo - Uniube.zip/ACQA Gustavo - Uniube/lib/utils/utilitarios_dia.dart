DateTime normalizarDia(DateTime data) {
  return DateTime(data.year, data.month, data.day);
}

bool ehMesmoDia(DateTime primeiraData, DateTime segundaData) {
  return primeiraData.year == segundaData.year &&
      primeiraData.month == segundaData.month &&
      primeiraData.day == segundaData.day;
}
