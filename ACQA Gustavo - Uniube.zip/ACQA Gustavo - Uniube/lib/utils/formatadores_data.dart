const List<String> _nomesDosMeses = <String>[
  'janeiro',
  'fevereiro',
  'marco',
  'abril',
  'maio',
  'junho',
  'julho',
  'agosto',
  'setembro',
  'outubro',
  'novembro',
  'dezembro',
];

String formatarMesEAno(DateTime data) {
  final String mes = _nomesDosMeses[data.month - 1];
  return '${mes[0].toUpperCase()}${mes.substring(1)} ${data.year}';
}

String formatarDataNumerica(DateTime data) {
  final String dia = data.day.toString().padLeft(2, '0');
  final String mes = data.month.toString().padLeft(2, '0');
  return '$dia/$mes/${data.year}';
}

String formatarDataLonga(DateTime data) {
  return '${data.day} de ${_nomesDosMeses[data.month - 1]} de ${data.year}';
}
