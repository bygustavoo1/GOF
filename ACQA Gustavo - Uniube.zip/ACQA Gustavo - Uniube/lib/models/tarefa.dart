class Tarefa {
  Tarefa({
    required this.titulo,
    required this.data,
    this.concluida = false,
  });

  final String titulo;
  final DateTime data;
  bool concluida;
}
