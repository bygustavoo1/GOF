import 'package:flutter/material.dart';

import '../controllers/controlador_tarefas.dart';
import '../widgets/andaime_aurora.dart';
import 'tela_calendario.dart';

class TelaAutenticacao extends StatefulWidget {
  const TelaAutenticacao({super.key, required this.controller});

  final ControladorTarefas controller;

  @override
  State<TelaAutenticacao> createState() => _TelaAutenticacaoState();
}

class _TelaAutenticacaoState extends State<TelaAutenticacao> {
  bool estaEmLogin = true;

  @override
  Widget build(BuildContext context) {
    return AndaimeAurora(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Spacer(),
          Text(
            estaEmLogin
                ? 'Entre no seu universo'
                : 'Crie sua conta brilhante',
            style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                  color: Colors.white,
                  height: 1.1,
                ),
          ),
          const SizedBox(height: 12),
          Text(
            'Organize o seu dia com cores vibrantes, foco leve e tarefas por data.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Colors.white.withOpacity(0.92),
                ),
          ),
          const SizedBox(height: 28),
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(32),
                boxShadow: const <BoxShadow>[
                  BoxShadow(
                    color: Color(0x33000000),
                    blurRadius: 30,
                    offset: Offset(0, 16),
                  ),
                ],
              ),
              child: Column(
                children: <Widget>[
                  _AlternadorAutenticacao(
                    estaEmLogin: estaEmLogin,
                    onChanged: (bool value) {
                      setState(() {
                        estaEmLogin = value;
                      });
                    },
                  ),
                  const SizedBox(height: 24),
                  _CampoBrilhante(
                    label: estaEmLogin ? 'Seu e-mail' : 'E-mail para cadastro',
                    icon: Icons.alternate_email_rounded,
                  ),
                  const SizedBox(height: 16),
                  _CampoBrilhante(
                    label: estaEmLogin ? 'Senha' : 'Crie uma senha',
                    icon: Icons.lock_outline_rounded,
                    obscureText: true,
                  ),
                  if (!estaEmLogin) ...<Widget>[
                    const SizedBox(height: 16),
                    const _CampoBrilhante(
                      label: 'Seu nome',
                      icon: Icons.favorite_outline_rounded,
                    ),
                  ],
                  const Spacer(),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<Widget>(
                            builder: (BuildContext context) {
                              return TelaCalendario(
                                controller: widget.controller,
                              );
                            },
                          ),
                        );
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF24104A),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                      ),
                      child: Text(
                        estaEmLogin ? 'Entrar' : 'Cadastrar',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        estaEmLogin = !estaEmLogin;
                      });
                    },
                    child: Text(
                      estaEmLogin
                          ? 'Ainda nao tem conta? Cadastre-se'
                          : 'Ja tem conta? Entrar',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF845EF7),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AlternadorAutenticacao extends StatelessWidget {
  const _AlternadorAutenticacao({
    required this.estaEmLogin,
    required this.onChanged,
  });

  final bool estaEmLogin;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xFFF3EEFF),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: _BotaoAlternancia(
              label: 'Entrar',
              selected: estaEmLogin,
              onTap: () => onChanged(true),
            ),
          ),
          Expanded(
            child: _BotaoAlternancia(
              label: 'Cadastrar',
              selected: !estaEmLogin,
              onTap: () => onChanged(false),
            ),
          ),
        ],
      ),
    );
  }
}

class _BotaoAlternancia extends StatelessWidget {
  const _BotaoAlternancia({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF845EF7) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: selected ? Colors.white : const Color(0xFF6A52A3),
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

class _CampoBrilhante extends StatelessWidget {
  const _CampoBrilhante({
    required this.label,
    required this.icon,
    this.obscureText = false,
  });

  final String label;
  final IconData icon;
  final bool obscureText;

  @override
  Widget build(BuildContext context) {
    return TextField(
      obscureText: obscureText,
      decoration: InputDecoration(
        filled: true,
        fillColor: const Color(0xFFF7F4FF),
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF845EF7)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
