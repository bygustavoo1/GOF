import 'package:flutter/material.dart';

import '../controllers/controlador_tarefas.dart';
import '../utils/formatadores_data.dart';
import '../utils/utilitarios_dia.dart';
import '../widgets/andaime_aurora.dart';
import 'tela_tarefas.dart';

class TelaCalendario extends StatefulWidget {
  const TelaCalendario({super.key, required this.controller});

  final ControladorTarefas controller;

  @override
  State<TelaCalendario> createState() => _TelaCalendarioState();
}

class _TelaCalendarioState extends State<TelaCalendario> {
  late DateTime mesVisivel;

  @override
  void initState() {
    super.initState();
    mesVisivel = DateTime(
      widget.controller.dataSelecionada.year,
      widget.controller.dataSelecionada.month,
    );
  }

  @override
  Widget build(BuildContext context) {
    final DateTime primeiroDiaDoMes =
        DateTime(mesVisivel.year, mesVisivel.month, 1);
    final int diasNoMes = DateTime(mesVisivel.year, mesVisivel.month + 1, 0).day;
    final int inicioDaSemana = primeiroDiaDoMes.weekday % 7;
    final List<Widget> blocosDeDias = <Widget>[];

    for (int index = 0; index < inicioDaSemana; index++) {
      blocosDeDias.add(const SizedBox.shrink());
    }

    for (int dia = 1; dia <= diasNoMes; dia++) {
      final DateTime dataAtual = DateTime(mesVisivel.year, mesVisivel.month, dia);
      final bool estaSelecionado =
          ehMesmoDia(dataAtual, widget.controller.dataSelecionada);

      blocosDeDias.add(
        GestureDetector(
          onTap: () {
            setState(() {
              widget.controller.selecionarData(dataAtual);
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            decoration: BoxDecoration(
              color: estaSelecionado ? const Color(0xFF24104A) : Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: const <BoxShadow>[
                BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 12,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Center(
              child: Text(
                '$dia',
                style: TextStyle(
                  color: estaSelecionado ? Colors.white : const Color(0xFF35205E),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
      );
    }

    return AndaimeAurora(
      showBackButton: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const SizedBox(height: 28),
          Text(
            'Escolha o dia',
            style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 10),
          Text(
            'Cada data abre uma lista exclusiva para organizar sua rotina.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Colors.white.withOpacity(0.92),
                ),
          ),
          const SizedBox(height: 24),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(32),
              ),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      IconButton(
                        onPressed: () {
                          setState(() {
                            mesVisivel = DateTime(
                              mesVisivel.year,
                              mesVisivel.month - 1,
                            );
                          });
                        },
                        icon: const Icon(Icons.chevron_left_rounded),
                      ),
                      Expanded(
                        child: Text(
                          formatarMesEAno(mesVisivel),
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(fontSize: 22),
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            mesVisivel = DateTime(
                              mesVisivel.year,
                              mesVisivel.month + 1,
                            );
                          });
                        },
                        icon: const Icon(Icons.chevron_right_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      _RotuloSemana('D'),
                      _RotuloSemana('S'),
                      _RotuloSemana('T'),
                      _RotuloSemana('Q'),
                      _RotuloSemana('Q'),
                      _RotuloSemana('S'),
                      _RotuloSemana('S'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: GridView.count(
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 7,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      children: blocosDeDias,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF2C6),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      children: <Widget>[
                        const Icon(
                          Icons.event_available_rounded,
                          color: Color(0xFF24104A),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Data selecionada: ${formatarDataNumerica(widget.controller.dataSelecionada)}',
                            style: const TextStyle(
                              color: Color(0xFF24104A),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<Widget>(
                            builder: (BuildContext context) {
                              return TelaTarefas(
                                controller: widget.controller,
                              );
                            },
                          ),
                        );
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFF5C8A),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                      ),
                      child: const Text(
                        'Ver tarefas do dia',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RotuloSemana extends StatelessWidget {
  const _RotuloSemana(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Text(
        label,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Color(0xFF8667C8),
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
