import 'package:flutter/material.dart';

import '../controllers/controlador_tarefas.dart';
import '../models/tarefa.dart';
import '../utils/formatadores_data.dart';
import '../widgets/andaime_aurora.dart';

class TelaTarefas extends StatelessWidget {
  const TelaTarefas({super.key, required this.controller});

  final ControladorTarefas controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (BuildContext context, Widget? child) {
        final List<Tarefa> tarefas = controller.tarefasDaDataSelecionada();

        return AndaimeAurora(
          showBackButton: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 28),
              Text(
                'Plano do dia',
                style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                      color: Colors.white,
                    ),
              ),
              const SizedBox(height: 10),
              Text(
                formatarDataLonga(controller.dataSelecionada),
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white.withOpacity(0.92),
                      fontWeight: FontWeight.w700,
                    ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(32),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              '${tarefas.length} tarefa(s)',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(fontSize: 22),
                            ),
                          ),
                          FilledButton.icon(
                            onPressed: () => _mostrarDialogoAdicionarTarefa(context),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF24104A),
                            ),
                            icon: const Icon(Icons.add_rounded),
                            label: const Text('Adicionar'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: tarefas.isEmpty
                            ? const _EstadoVazioTarefas()
                            : ListView.separated(
                                itemCount: tarefas.length,
                                separatorBuilder:
                                    (BuildContext context, int index) {
                                  return const SizedBox(height: 12);
                                },
                                itemBuilder: (BuildContext context, int index) {
                                  final Tarefa tarefa = tarefas[index];

                                  return _CartaoTarefa(
                                    tarefa: tarefa,
                                    onToggle: () => controller.alternarTarefa(tarefa),
                                    onDelete: () => controller.removerTarefa(tarefa),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _mostrarDialogoAdicionarTarefa(BuildContext context) async {
    final TextEditingController controladorTexto = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Nova tarefa'),
          content: TextField(
            controller: controladorTexto,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Digite a tarefa do dia',
            ),
            onSubmitted: (_) {
              controller.adicionarTarefa(controladorTexto.text);
              Navigator.of(context).pop();
            },
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                controller.adicionarTarefa(controladorTexto.text);
                Navigator.of(context).pop();
              },
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );

    controladorTexto.dispose();
  }
}

class _CartaoTarefa extends StatelessWidget {
  const _CartaoTarefa({
    required this.tarefa,
    required this.onToggle,
    required this.onDelete,
  });

  final Tarefa tarefa;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final bool estaConcluida = tarefa.concluida;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2C174D),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: <Widget>[
          Checkbox(
            value: estaConcluida,
            onChanged: (_) => onToggle(),
            activeColor: const Color(0xFF24104A),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  tarefa.titulo,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    decoration:
                        estaConcluida ? TextDecoration.lineThrough : null,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  estaConcluida ? 'Concluida' : 'Pendente',
                  style: const TextStyle(
                    color: Color(0xFFD8C8FF),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onDelete,
            icon: const Icon(Icons.delete_outline_rounded),
            color: Colors.white,
          ),
        ],
      ),
    );
  }
}

class _EstadoVazioTarefas extends StatelessWidget {
  const _EstadoVazioTarefas();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F1FF),
        borderRadius: BorderRadius.circular(28),
      ),
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(
            Icons.auto_awesome_rounded,
            size: 56,
            color: Color(0xFF845EF7),
          ),
          SizedBox(height: 16),
          Text(
            'Nenhuma tarefa por aqui ainda.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: Color(0xFF24104A),
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Use o botao Adicionar para criar a primeira atividade desse dia.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF5F4A95),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
