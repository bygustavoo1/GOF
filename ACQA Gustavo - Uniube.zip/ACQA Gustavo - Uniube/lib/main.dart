import 'package:flutter/material.dart';

import 'controllers/controlador_tarefas.dart';
import 'screens/tela_autenticacao.dart';

void main() {
  runApp(const AplicativoTarefas());
}

class AplicativoTarefas extends StatelessWidget {
  const AplicativoTarefas({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = ControladorTarefas();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Glow Tasks',
      theme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF5C8A),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF9F4FF),
        textTheme: const TextTheme(
          headlineLarge: TextStyle(
            fontSize: 34,
            fontWeight: FontWeight.w800,
            color: Color(0xFF24104A),
          ),
          headlineSmall: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: Color(0xFF24104A),
          ),
          bodyLarge: TextStyle(
            fontSize: 16,
            color: Color(0xFF3D2B66),
          ),
        ),
      ),
      home: TelaAutenticacao(controller: controller),
    );
  }
}
