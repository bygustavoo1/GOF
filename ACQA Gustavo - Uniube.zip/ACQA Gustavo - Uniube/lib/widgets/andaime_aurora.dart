import 'package:flutter/material.dart';

class AndaimeAurora extends StatelessWidget {
  const AndaimeAurora({
    super.key,
    required this.child,
    this.showBackButton = false,
    this.onBack,
  });

  final Widget child;
  final bool showBackButton;
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF2C174D),
        child: SafeArea(
          child: Stack(
            children: <Widget>[
              Positioned(
                top: -60,
                right: -30,
                child: _BolhaBrilho(
                  size: 180,
                  color: Colors.white.withOpacity(0.18),
                ),
              ),
              Positioned(
                left: -50,
                bottom: 120,
                child: _BolhaBrilho(
                  size: 160,
                  color: Colors.white.withOpacity(0.12),
                ),
              ),
              if (showBackButton)
                Positioned(
                  top: 12,
                  left: 12,
                  child: IconButton(
                    onPressed: onBack ?? () => Navigator.of(context).maybePop(),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.18),
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 28, 20, 20),
                child: child,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BolhaBrilho extends StatelessWidget {
  const _BolhaBrilho({
    required this.size,
    required this.color,
  });

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
      ),
    );
  }
}
