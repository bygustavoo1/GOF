import 'package:flutter/foundation.dart';

import '../models/tarefa.dart';
import '../utils/utilitarios_dia.dart';

class ControladorTarefas extends ChangeNotifier {
  DateTime _dataSelecionada = normalizarDia(DateTime.now());
  final Map<DateTime, List<Tarefa>> _tarefasPorDia = <DateTime, List<Tarefa>>{};

  DateTime get dataSelecionada => _dataSelecionada;

  void selecionarData(DateTime data) {
    _dataSelecionada = normalizarDia(data);
    notifyListeners();
  }

  List<Tarefa> tarefasDaDataSelecionada() {
    final tarefas = List<Tarefa>.from(
      _tarefasPorDia[normalizarDia(_dataSelecionada)] ?? <Tarefa>[],
    );

    tarefas.sort((Tarefa a, Tarefa b) {
      if (a.concluida != b.concluida) {
        return a.concluida ? 1 : -1;
      }

      return a.titulo.toLowerCase().compareTo(b.titulo.toLowerCase());
    });

    return tarefas;
  }

  void adicionarTarefa(String titulo) {
    final tituloTratado = titulo.trim();

    if (tituloTratado.isEmpty) {
      return;
    }

    final dia = normalizarDia(_dataSelecionada);
    final tarefas = _tarefasPorDia.putIfAbsent(dia, () => <Tarefa>[]);

    tarefas.add(
      Tarefa(
        titulo: tituloTratado,
        data: dia,
        concluida: false,
      ),
    );
    notifyListeners();
  }

  void alternarTarefa(Tarefa tarefa) {
    tarefa.concluida = !tarefa.concluida;
    notifyListeners();
  }

  void removerTarefa(Tarefa tarefa) {
    final dia = normalizarDia(tarefa.data);
    final tarefas = _tarefasPorDia[dia];

    if (tarefas == null) {
      return;
    }

    tarefas.remove(tarefa);

    if (tarefas.isEmpty) {
      _tarefasPorDia.remove(dia);
    }

    notifyListeners();
  }
}
